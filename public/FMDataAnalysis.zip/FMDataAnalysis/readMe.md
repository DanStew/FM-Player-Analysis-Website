This is a football manager data analyser that is used to help prove squad strength and suggest transfers
It is python code implemented by using a text file from the game, inspired by similar project made by squirrel_plays
I haven't personally seen or used the code made by squirrel, however the idea itself was inspired from what his code was capable of doing

Directory Contents : 
roleEvaluator - Used to evaluate players attributes to how well suited they would be for roles
FMViews - Folder with views that can be imported into FM, to create the needed output for FMData
FMData - Folder where data exported from FM is put
AttributeRankings - Contains the attribute ranking information
OutputTables - Folder where output HTML tables will be stored
GUIFiles - Folder where the QML files needed to make the GUI are stored
